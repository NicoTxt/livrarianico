rm esmforum.db

sqlite3 esmforum.db < schema.sql