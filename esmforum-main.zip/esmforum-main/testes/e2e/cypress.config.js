module.exports = {
  fixturesFolder: false,
  chromeWebSecurity: false,
  e2e: {
    setupNodeEvents(on, config) {},
    supportFile: false,
  },
}
